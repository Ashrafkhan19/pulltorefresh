package com.example.swipetorefresh

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.swipetorefresh.ui.theme.SwipeToRefreshTheme
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContent {
            var isRefreshing by remember {
                mutableStateOf( false)
            }
            var msg by remember {
                mutableStateOf("Hello")
            }

            var itemSize by remember {
                mutableStateOf(15)
            }
            var i = 0

            val refreshState = rememberSwipeRefreshState(isRefreshing)
            val state = rememberLazyListState()
            val list =
                MutableList(itemSize){
                    "$msg $it"

            }



            SwipeToRefreshTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SwipeRefresh(state = refreshState, onRefresh = {
                        lifecycleScope.launch {
                            isRefreshing = true
                            msg = "Welcome"
                            delay(1000L)
                            isRefreshing = false
                        }
                    }) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceEvenly,
                            state = state
                        ) {
                            items(list) {
                                Box(
                                    modifier = Modifier
                                        .padding(10.dp)
                                        .fillMaxWidth(.8f)
                                        .background(
                                            MaterialTheme.colorScheme.inversePrimary,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(25.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = it,
                                        fontSize = MaterialTheme.typography.bodySmall.fontSize,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }

                            }


                        }
                        val endOfListReached by remember {
                            derivedStateOf {
                                state.isScrolledToEnd()
                            }
                        }

                        LaunchedEffect(key1 = endOfListReached ){
                            //Toast.makeText(applicationContext, i++.toString(), Toast.LENGTH_SHORT).show()
                            itemSize += 1
                        }
                    }}
            }}
    }
}

private fun LazyListState.isScrolledToEnd():Boolean {
    val lastItem = layoutInfo.visibleItemsInfo.lastOrNull()
    return lastItem == null || lastItem.size + lastItem.offset <= layoutInfo.viewportEndOffset

}

@Composable
fun Greeting(name: String) {
    Text(text = "Hello $name!")
}

@Composable
fun CardItem(item: String = "") {

    Box(
        modifier = Modifier
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .fillMaxWidth(0.8f)
            .background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center
    ) {
        Text(text = "Hello $item", fontSize = MaterialTheme.typography.displaySmall.fontSize)
    }

}

@Preview(showBackground = true)
@Composable
fun PreviewCardItem() {
    val isRefreshing by remember {
        mutableStateOf( true)
    }

    val refreshState = rememberSwipeRefreshState(isRefreshing)
    val state = rememberLazyListState()
    val list = MutableList(15){
        "Hello $it"
    }

    SwipeToRefreshTheme {
        // A surface container using the 'background' color from the theme
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            SwipeRefresh(state = refreshState, onRefresh = {  }) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                items(list) {
                    Box(
                        modifier = Modifier
                            .padding(10.dp)
                            .fillMaxWidth(.8f)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                            .padding(25.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = it,
                            fontSize = MaterialTheme.typography.bodySmall.fontSize
                        )
                    }
                }
            }
        }}
    }
}

